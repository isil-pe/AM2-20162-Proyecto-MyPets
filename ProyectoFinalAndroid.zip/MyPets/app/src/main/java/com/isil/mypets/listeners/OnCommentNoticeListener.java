package com.isil.mypets.listeners;

/**
 * Created by Alexander on 29/11/2016.
 */
public interface OnCommentNoticeListener {
    void volverNoticiaDetalle(String id);
}
