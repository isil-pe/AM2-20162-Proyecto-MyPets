package com.isil.mypets.listeners;

/**
 * Created by eduardo on 04/09/16.
 */
public interface OnNavListener {
}
