package com.isil.mypets.listeners;

/**
 * Created by Alumno-J on 23/11/2016.
 */
public interface OnNoticeListener {
    void mostrarNoticiaDetalle(String id);
    void volverListarNoticia();
    void verComentariosNoticia(String id);
}
